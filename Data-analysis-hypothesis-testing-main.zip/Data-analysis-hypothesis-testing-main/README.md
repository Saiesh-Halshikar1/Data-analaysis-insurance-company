# Data-analysis-hypothesis-testing
Data analysis and hypothesis testing was done for an insurance company with the help of different graphs &amp; plots using matplot library. Correlation matrix ,scatter plot and p-value were extracted to find the dependencies.
